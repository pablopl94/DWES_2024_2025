package eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdtActividad4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
