package eventos.dao;

import eventos.entidades.Tipo;

public interface TipoDao extends IGenericoCrud<Tipo, Integer>{
	
}
