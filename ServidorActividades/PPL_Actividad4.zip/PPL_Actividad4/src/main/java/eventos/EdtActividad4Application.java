package eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdtActividad4Application {

	public static void main(String[] args) {
		SpringApplication.run(EdtActividad4Application.class, args);
	}

}
